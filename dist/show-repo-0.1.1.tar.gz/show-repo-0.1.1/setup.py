# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['show_repo']

package_data = \
{'': ['*']}

install_requires = \
['GitPython>=3.1.27,<4.0.0',
 'click>=8.1.3,<9.0.0',
 'colorama>=0.4.5,<0.5.0',
 'tabulate>=0.8.10,<0.9.0']

entry_points = \
{'console_scripts': ['sr = show_repo.cli:cli']}

setup_kwargs = {
    'name': 'show-repo',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'Adam Hoffstein',
    'author_email': 'adam.hoffstein@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
